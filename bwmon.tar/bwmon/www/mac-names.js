/**
 * This file is used by the HTML tool to match up friendly names please follow the format below (this is a standard javascript dictionary).
 */

 var MAC_NAMES = {
'01:23:45:67:89:AB': 'First and every other pc name',
'00:11:22:33:44:55': 'Last PC Name'
};
